===================
HOW TO USE THE CODE:
===================

We present, descibe and implememnt template-free method that can be used to
carry out blind searches of any types of GW irrespective of the waveform 
and of the source type and sky location.

The method is based on cross-correlation and on phenomenological 
information: in short, a GW is detected if the strain data where the search
is performed presents a correlation-coefficient with a time-lag that is no 
greater than the expected inter-site propagation time.

This code can be easily used to search gravitational waves (GW) using data
from the two LIGO observatories simultaneously. 

The code is focused to detect GW signals (events or injections) that are 
embedded in the freely available LIGO data recorded during the first 
observation run (O1)

To run de code, you only need to follow these simple instructions:
1) Open the script "mainscript.m"
2) Select a data block "DataBlock line 11
3) Select a width for the time window "Tslice", line 11
4) Excute the script



===================
IMPORTANT NOTICES:
===================

1) This research has made use of data, software and/or web tools obtained 
from the Gravitational Wave Open Science Center 
https://www.gw-openscience.org), a service of LIGO Laboratory, the LIGO 
Scientific Collaboration and the Virgo Collaboration. LIGO is funded by the
U.S. National Science Foundation. Virgo is funded by the French Centre 
National de Recherche Scientifique (CNRS), the Italian Istituto Nazionale
della Fisica Nucleare (INFN) and the Dutch Nikhef, with contributions by 
Polish and Hungarian institutes.

2) LIGO Data from O1 is freealy available at 
https://www.gw-openscience.org/archive/O1/

3) You need to download all O1 data bloks containing an injection. See 
https://www.gw-openscience.org/o1_inj/

4) Data blocks should be saved in D:\_DataSets\LIGOO1\ (or change the path
in gw_readligo.m)



===================
REFERENCE:
===================

If you use this code in your research, please use the following reference:
Javier M. Antelis, Claudia Moreno. Gen Relativ Gravit (2019) XX: XX. https://doi.org/10.XXX/XXXXXX-XXX-XXXX-X


