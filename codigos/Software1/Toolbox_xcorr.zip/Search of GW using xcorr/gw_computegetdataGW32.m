function data = gw_computegetdataGW32(ligo,doplot)
% Compute



%% GET DATA SEGMENT

% Initialize data segment structure
data.st                    = [];
data.t                     = [];
data.timegps               = [];
data.sf                    = [];
data.f                     = [];
data.psd                   = [];
data.fpsd                  = [];

data.st                    = ligo.strain;
data.t                     = ligo.timesec;
data.timegps               = ligo.timegps;

data.fs                    = ligo.fs;
data.NFFT                  = length(ligo.strain);
data.st_window             = blackman(data.NFFT);

% data.segments              = ligo.segments;

if (1)
    % two-sided FFT    
    data.sf        = fft(data.st .* data.st_window) ./ data.fs;
    data.f         = ( linspace(0,data.fs,length(data.sf)) )';
    
else
    % sigle-sided FFT
    
    % Construct inverse window 
    data.inv_win   = (1./data.st_window);
    
    % Reject 4 seconds on edges due to window edge effects
    tr                         = 4;
    ind2eli                    = 1:tr*data.fs;
    data.inv_win(ind2eli)      = 0;
    ind2eli                    = length(data.inv_win)-tr*data.fs:length(data.inv_win);
    data.inv_win(ind2eli)      = 0;
    
    % Compute single-sided FFT of the data segment
    data.NFFT = data.NFFT*2;
    data.sf                    = fft(data.st .* data.st_window,data.NFFT);
    data.sf                    = data.sf(1:(data.NFFT/2)+0);
    data.f                     = ( linspace(0,data.fs/2,length(data.sf)) )';
end



%% Plot strain data time-domain and two-sided FFT
if (doplot)
    figure, hold on
    plot(data.f,abs(data.sf),'LineWidth',2)
    grid on, box on
    xlabel('Frequency (Hz)'), ylabel('Magnitude (?)'), 
    title('|s(f)|: strain data FFT magnitude')
    set(gca,'XScale','Linear','YScale','Log') % Linear
    %set(gca,'XLim',[10 data.fs]), 
    %set(gca,'YLim',[1e-24 1e-20])
    
    % Undertanding the frequency vector:
    %figure
    %stem(data.f)
end
