function [DataSlicesWithDT, ResultsAllSlices] = gw_computexcorr_v2(dataH1,dataL1,Twin,TrHo,doplot)



% ----------------------------------------
% Initialize outputs
DataSlicesWithDT              = [];
ResultsAllSlices              = []; 

% ----------------------------------------
% Initialize slices structure
Tblock                   = round(dataL1.t(end)-dataL1.t(1));
Tove                     = Twin/2;
InfoSlice                = gw_getsegmentsinfo(Tblock,Twin,Tove,dataH1.fs); % Overlap del 50%

% ----------------------------------------
% Save xcorr and tcor for each slice
ResultsAllSlices.Nslices      = InfoSlice.Nseg;

% ----------------------------------------
% Save xcorr and tcor for each slice
ResultsAllSlices.slicexcor    = zeros(InfoSlice.Nseg,2*Twin*dataH1.fs-1);
ResultsAllSlices.slicetcor    = zeros(InfoSlice.Nseg,2*Twin*dataH1.fs-1);

% ----------------------------------------
% Define Tlag threshold (in ms)
ResultsAllSlices.THlag        = 10/1000;

% ----------------------------------------
% Define xcor and corr thresholds
ResultsAllSlices.THxcor       = NaN(InfoSlice.Nseg,1);
ResultsAllSlices.THcorr       = NaN(InfoSlice.Nseg,1);

% ----------------------------------------
% Initialize
ResultsAllSlices.timeseg      = sum(InfoSlice.Tint,2)/2;
ResultsAllSlices.timegpsseg   = 0*ResultsAllSlices.timeseg;
ResultsAllSlices.corr         = zeros(InfoSlice.Nseg,1);
ResultsAllSlices.xcor         = zeros(InfoSlice.Nseg,1);
ResultsAllSlices.lag          = zeros(InfoSlice.Nseg,1);
ResultsAllSlices.SliceMarker  = zeros(InfoSlice.Nseg,1);
ResultsAllSlices.DetectionTrigger      = zeros(InfoSlice.Nseg,1);

% ----------------------------------------
% For each segment ...
for i=1:InfoSlice.Nseg
    % fprintf('            segment %d \n',i)
    
    % ... get H1 and L1 data
    H1segment            = 1e21*dataH1.st(InfoSlice.Sint(i,1):InfoSlice.Sint(i,2));
    L1segment            = 1e21*dataL1.st(InfoSlice.Sint(i,1):InfoSlice.Sint(i,2));
    t                    = dataH1.t(InfoSlice.Sint(i,1):InfoSlice.Sint(i,2));
    timegps              = dataH1.timegps(InfoSlice.Sint(i,1):InfoSlice.Sint(i,2));
    
    ResultsAllSlices.timegpsseg(i,1)  = (timegps(end)-timegps(1))/2 + timegps(1);
    
    % ... compte the cross-correlation
    [xcor,xlags]         = xcorr(H1segment,L1segment,'coeff');
    tcor                 = xlags/dataH1.fs + dataL1.t(1);
    
    % Save cor and tcor for the current slice
    ResultsAllSlices.slicexcor(i,:) = xcor;
    ResultsAllSlices.slicetcor(i,:) = tcor;
    
    % ... compute threshold;
    %ResultsAllSlices.THxcor(i,1)      = 6*std(xcor);
    ResultsAllSlices.THxcor(i,1)      = TrHo*std(xcor);
    ResultsAllSlices.THcorr(i,1)      = ResultsAllSlices.THxcor(i,1)^2;
    
    % ... get the maximum 'corr' and its corresponding 'xcor' and 'lag'
    [~,I]                             = max(xcor.^2);   % Index of the maximum corr
    ResultsAllSlices.corr(i,1)        = xcor(I)^2;      % Maximum corr
    ResultsAllSlices.xcor(i,1)        = xcor(I);        % xcor of the maximum corr
    ResultsAllSlices.lag(i,1)         = tcor(I);        % lag of the maximum corr
    
    % ... "segment with naive detection" if: corr>THcorr and |lag|<10ms
    if and(ResultsAllSlices.corr(i,1)>ResultsAllSlices.THcorr(i,1),abs(ResultsAllSlices.lag(i,1))<=ResultsAllSlices.THlag)
        ResultsAllSlices.SliceMarker(i)   = 1;
        % ... and the i and i-1 segments are "segment with trigger" if they are are segments with detection
        if i>=2
            if ResultsAllSlices.SliceMarker(i-1)==ResultsAllSlices.SliceMarker(i)
                %ResultsAllSlices.DetectionTrigger(i-1)      = 1;
                ResultsAllSlices.DetectionTrigger( i )      = 1;
                fprintf('*** DETECTION ***\n')
                fprintf('Corr: %1.3f \n',ResultsAllSlices.corr(i,1))
                fprintf('xcor: %1.3f \n',ResultsAllSlices.xcor(i,1))
                fprintf('Tlag: %1.3f ms \n',ResultsAllSlices.lag(i,1))
                fprintf('\n')
            end % if ResultsAllSlices.SliceMarker(i-1)==ResultsAllSlices.SliceMarker(i)
        end % if i>=2
        
        
    else
        % NO DETECTION
        %ResultsAllSlices.SliceMarker(i)       = 0;
        %ResultsAllSlices.DetectionTrigger(i)  = 0;
    end % if ResultsAllSlices.corr(i,1)>ResultsAllSlices.THcorr(i,1)
    
    % Plot for debugging
    if (doplot)
        
        if (1)
            figure(2), clf
            
            subplot(4,1,1), hold on
            area([timegps(1) timegps(end)],[1 1]*2e-21,'BaseValue',-2e-21,'FaceColor',[0.93 0.93 0.93],'LineStyle','none'), hold on % ,'FaceAlpha',0.5
            plot(dataH1.timegps,dataH1.st,'-','Color',[1.0 0.0 0.0],'LineWidth',1)
            plot(dataL1.timegps,dataL1.st,'-','Color',[0.0 0.5 0.0],'LineWidth',1)
            set(gca,'XLim',[dataL1.timegps(1) dataL1.timegps(end)]),
            xlabel('Time (gps)'), ylabel('Strain')
            title('Cleaned data segment')
            grid on, box on
            
            subplot(4,1,2)
            plot(timegps,H1segment,'-','Color',[1.0 0.0 0.0],'LineWidth',1), hold on
            plot(timegps,L1segment,'-','Color',[0.0 0.5 0.0],'LineWidth',1), hold on
            set(gca,'XLim',[timegps(1) timegps(end)]), %set(gca,'YLim',[-2 2]),
            xlabel('Time (gps)'), ylabel('Strain')
            title('Cleaned data slice')
            grid on, box on
            
            subplot(4,1,3)
            plot(tcor,xcor,'b'), hold on
            set(gca,'YLim',[-1 1]),
            ylabel('xcorr'), xlabel('Time-shift (s)')
            grid off, box on
            plot([ResultsAllSlices.lag(i) ResultsAllSlices.lag(i)],[-1 1],'-r')
            
            plot(Twin*[-1 1],+ResultsAllSlices.THxcor(i,1)*[1 1],':k','LineWidth',2)
            plot(Twin*[-1 1],-ResultsAllSlices.THxcor(i,1)*[1 1],':k','LineWidth',2)
            plot(-ResultsAllSlices.THlag*[1 1],[-1 1],':k','LineWidth',2)
            plot(+ResultsAllSlices.THlag*[1 1],[-1 1],':k','LineWidth',2)
            title(['xcorr=' num2str(ResultsAllSlices.xcor(i)) '   |   Time-shift=' num2str(1000*round(ResultsAllSlices.lag(i)*10000)/10000) 'ms'])
            
            
            
            subplot(4,1,4)
            stem(ResultsAllSlices.timegpsseg(1:i),ResultsAllSlices.DetectionTrigger(1:i))
            set(gca,'XLim',[dataL1.timegps(1) dataL1.timegps(end)]),
            set(gca,'YLim',[0 1])
            xlabel('Time (gps)'), ylabel('Detection Trigger')
            title(['Slice ' num2str(i)])
            grid on, box on
            
            drawnow
            
        else
            figure(1), clf
            
            subplot(4,1,1), hold on
            area(InfoSlice.Tint(i,:),[1 1]*2e-21,'BaseValue',-2e-21,'FaceColor',[0.93 0.93 0.93],'LineStyle','none'), hold on % ,'FaceAlpha',0.5
            plot(dataH1.t,dataH1.st,'-','Color',[1.0 0.0 0.0],'LineWidth',1)
            plot(dataL1.t,dataL1.st,'-','Color',[0.0 0.5 0.0],'LineWidth',1)
            set(gca,'XLim',[dataL1.t(1) dataL1.t(end)]),
            xlabel('Time (s)'), ylabel('Strain')
            title('Whitened and band-pass filtered strain data blok')
            grid on, box on
            
            subplot(4,1,2)
            plot(t,H1segment,'-','Color',[1.0 0.0 0.0],'LineWidth',1), hold on
            plot(t,L1segment,'-','Color',[0.0 0.5 0.0],'LineWidth',1), hold on
            set(gca,'XLim',[t(1) t(end)]), %set(gca,'YLim',[-2 2]),
            xlabel('Time (s)'), ylabel('Strain')
            title('Whitened and band-pass filtered strain data segment')
            grid on, box on
            
            subplot(4,1,3)
            plot(tcor,xcor,'b'), hold on
            set(gca,'YLim',[-1 1]),
            ylabel('xcorr'), xlabel('Time-shift (s)')
            grid off, box on
            plot([ResultsAllSlices.lag(i) ResultsAllSlices.lag(i)],[-1 1],'-r')
            
            plot(Twin*[-1 1],+ResultsAllSlices.THxcor(i,1)*[1 1],':k','LineWidth',2)
            plot(Twin*[-1 1],-ResultsAllSlices.THxcor(i,1)*[1 1],':k','LineWidth',2)
            plot(-ResultsAllSlices.THlag*[1 1],[-1 1],':k','LineWidth',2)
            plot(+ResultsAllSlices.THlag*[1 1],[-1 1],':k','LineWidth',2)
            title(['xcorr=' num2str(round(ResultsAllSlices.xcor(i)*1000)/1000) '   |   Time-shift=' num2str(1000*round(ResultsAllSlices.lag(i)*10000)/10000) 'ms'])
            
            subplot(4,1,4)
            stem(ResultsAllSlices.timeseg(1:i),ResultsAllSlices.DetectionTrigger(1:i))
            set(gca,'XLim',[dataL1.t(1) dataL1.t(end)]), set(gca,'YLim',[0 1])
            xlabel('Time (s)'), ylabel('Trigger')
            title(['Segment ' num2str(i)])
            grid on, box on
            
            drawnow
            
        end % if (1)
        
        % Pause if detection
        if ResultsAllSlices.DetectionTrigger(i)==1
            pause
        end % ResultsAllSlices.DetectionTrigger(i)==1
        
    end % if (0)
    
end % for i=1:InfoSlice.Nseg
clear ans i I t H1segment L1segment tcor xcor xlags

% ----------------------------------------
% Plot final results
if (doplot)
    figure
    
    subplot(3,1,1), hold on
    stem(ResultsAllSlices.timeseg,ResultsAllSlices.xcor,'.')
    line([ResultsAllSlices.timeseg(1)-ResultsAllSlices.timeseg(1) ResultsAllSlices.timeseg(end)+ResultsAllSlices.timeseg(1)],+[1 1]*ResultsAllSlices.THxcor(i,1),'Color','red','LineStyle','--')
    line([ResultsAllSlices.timeseg(1)-ResultsAllSlices.timeseg(1) ResultsAllSlices.timeseg(end)+ResultsAllSlices.timeseg(1)],-[1 1]*ResultsAllSlices.THxcor(i,1),'Color','red','LineStyle','--')
    set(gca,'YLim',[-1 1])
    set(gca,'Xlim',[ResultsAllSlices.timeseg(1)-ResultsAllSlices.timeseg(1) ResultsAllSlices.timeseg(end)+ResultsAllSlices.timeseg(1)])
    title('Correlation')
    ylabel('corr')
    box on
    
    subplot(3,1,2), hold on
    stem(ResultsAllSlices.timeseg,ResultsAllSlices.lag*1000,'.')
    line([ResultsAllSlices.timeseg(1)-ResultsAllSlices.timeseg(1) ResultsAllSlices.timeseg(end)+ResultsAllSlices.timeseg(1)],+[1 1]*ResultsAllSlices.THlag,'Color','red','LineStyle','--')
    line([ResultsAllSlices.timeseg(1)-ResultsAllSlices.timeseg(1) ResultsAllSlices.timeseg(end)+ResultsAllSlices.timeseg(1)],-[1 1]*ResultsAllSlices.THlag,'Color','red','LineStyle','--')
    set(gca,'YLim',[-1 1]*1000*round(max(abs(ResultsAllSlices.lag))*100)/100)
    set(gca,'Xlim',[ResultsAllSlices.timeseg(1)-ResultsAllSlices.timeseg(1) ResultsAllSlices.timeseg(end)+ResultsAllSlices.timeseg(1)])
    title('Time lag')
    ylabel('ms')
    box on
    
    subplot(3,1,3), hold on
    stem(ResultsAllSlices.timeseg,ResultsAllSlices.DetectionTrigger,'.')
    set(gca,'YLim',[ 0 1])
    set(gca,'Xlim',[ResultsAllSlices.timeseg(1)-ResultsAllSlices.timeseg(1) ResultsAllSlices.timeseg(end)+ResultsAllSlices.timeseg(1)])
    title('Trigger')
    xlabel('Time (s)')
    box on
    
end % if (0)



%% GET THE INFO FOR EACH SEGMENT

% ----------------------------------------
% Get the info
if any(ResultsAllSlices.DetectionTrigger)
    
    % Get the ID of the slices with detection
    DataSlicesWithDT.SliceWithDT = find(ResultsAllSlices.DetectionTrigger);
    
    % Save the info of each slice with detection
    for i=1:length(DataSlicesWithDT.SliceWithDT)
        isegswithtrig              = DataSlicesWithDT.SliceWithDT(i);
        DataSlicesWithDT.lag(i,1)       = ResultsAllSlices.lag(isegswithtrig);
        DataSlicesWithDT.xcor(i,1)      = ResultsAllSlices.xcor(isegswithtrig);
        
        indices                    = InfoSlice.Sint(isegswithtrig,1):InfoSlice.Sint(isegswithtrig,2);
        DataSlicesWithDT.time(:,i)      = dataH1.t(indices);
        DataSlicesWithDT.timegps(:,i)   = dataH1.timegps(indices);
        DataSlicesWithDT.strainH1(:,i)  = dataH1.st(indices);
        DataSlicesWithDT.strainL1(:,i)  = dataL1.st(indices);
        
        DataSlicesWithDT.slicexcor(:,i) = ResultsAllSlices.slicexcor(isegswithtrig,:);
        DataSlicesWithDT.slicetcor(:,i) = ResultsAllSlices.slicetcor(isegswithtrig,:);
        
    end % for i=1:DataSlicesWithDT.Ntri
end % if any(ResultsAllSlices.DetectionTrigger)
clear ans i indices