function Segments = gw_getsegmentsinfo(Tblock,Twin,Tove,fs)
%
% Esta funcion funciona unicamente para overlap del 50%
%
% Tblock  = 4096;
% Twin    = 32;
% Tove    = Twin/2;
% fs      = 4096;

% Initialize
Segments        = [];

% Duration of the segment
Segments.Tblock = Tblock;

% Duration of the data segment and overlap (seconds)
Segments.Twin   = Twin;
Segments.Tove   = Tove;

% Number of segments
Segments.Nseg   = 2*(Segments.Tblock/Segments.Twin)-1;

% Time ini and Time end of each segment (seconds)
Tini            = (0:Segments.Tove:Segments.Tblock-2*Segments.Tove)';
Tend            = Tini+Segments.Twin;

% Sample ini and Sample end of each segment (sample)
Sini            = Tini*fs+1;
Send            = Tend*fs+0;

% Time and samples of each interval
Segments.Tint   = [Tini Tend];
Segments.Sint   = [Sini Send];

% Clear garbage
clear ans Tini Tend Sini Send


%%
% clc
% Tblock  = 4096;
% Twin    = 32;
% Tove    = 8;
% fs      = 4096;
% 
% Tini            = (0:Twin-Tove:Tblock-Twin)';
% Tend            = Tini+Twin;
% 
% [Tini Tend]



