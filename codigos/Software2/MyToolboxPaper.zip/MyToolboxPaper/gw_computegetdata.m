function data = gw_computegetdata(ligo)
%
% compute h(t) using 2PN aproximation
% compute h(f) using the stationary phase aproximation
%
%   $Revision: 0.01 $  $Date: 2015/10/16 13:26:32 $
%   Designed by Javier M. Antelis & Claudia Moreno
%   $ gw_computegetdata.m $
%
% INPUT:
%    ligo      - structure with ligo data and info
%
% OUTPUT:
%    data      - structure with data segment in time and frequency domain



%% GET DATA SEGMENT

% Initialize data segment structure
data.st                    = [];
data.t                     = [];
data.sf                    = [];
data.f                     = [];
data.psd                   = [];
data.fpsd                  = [];

% Compute the window the data segment
data.st_window             = blackman(ligo.NFFT);
% Construct inverse window 
data.inv_win               = (1./data.st_window);

% Reject 20 seconds on edges due to window edge effects
tr                         = ceil(0.15*ligo.segments.Twin);
ind2eli                    = 1:tr*ligo.fs;
data.inv_win(ind2eli)      = 0;
ind2eli                    = length(data.inv_win)-tr*ligo.fs:length(data.inv_win);
data.inv_win(ind2eli)      = 0;

% Get the data segment
iseg                       = ligo.segments.seginj;
data.st                    = ligo.strain(ligo.segments.Sint(iseg,1):ligo.segments.Sint(iseg,2));
data.t                     = ligo.timegps(ligo.segments.Sint(iseg,1):ligo.segments.Sint(iseg,2));

% Compute single-sided FFT of the data segment
data.sf                    = fft(data.st .* data.st_window,ligo.NFFT);
data.sf                    = data.sf(1:(ligo.NFFT/2)+1);
data.f                     = ( linspace(0,ligo.fs/2,length(data.sf)) )';

% Save other info
data.fs                    = ligo.fs;
data.NFFT                  = ligo.NFFT;


% Save injection info
data.injection             = ligo.injection;

% Clear garbage
clear ans tr ind2eli iseg


% Plot dtrain data sigle-sided FFT
if (0)
    figure, hold on
    plot(data.f,abs(data.sf),'k','LineWidth',2)
    grid on, box on
    xlabel('Frequency   [Hz]'), ylabel('Spectral Power [Hz^{-1/2}]'), title('s(f): Strain data sigle-sided FFT')
    set(gca,'XLim',[1 data.injection.fs/2],'XScale','Log','YScale','Log')
end
