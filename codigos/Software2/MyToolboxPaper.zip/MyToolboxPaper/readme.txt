===================
HOW TO USE THE CODE:
===================

This code can be used to perform detection of GW from inspiral binary systems. 
The code is focused to detect GW waveform that are embedded in the freely available LIGO data recorded during the fifth science run (S5).

To perfor detection, you only need to follow these simple instructions:
1) Open the script "mainscript.m"
2) Select an interferometer, line 7
3) Select a data block file, line 10
4) Excute the scrip



===================
IMPORTANT NOTICES:
===================

1) This research has made use of data, software and/or web tools obtained from the LIGO Open Science Center (https://losc.ligo.org), a service of LIGO Laboratory and the LIGO Scientific Collaboration. LIGO is funded by the U.S. National Science Foundation. The authors deeply acknowledges LIGO team.
2) LIGO Data from S5 is freealy available at https://losc.ligo.org/data/
3) You need to download data bloks containing and injection
4) Data blocks should be saved in C:\_DataSets\Data_LIGOS5\



===================
REFERENCE:
===================

If you use this code in your research, you should use the following reference:
Javier M. Antelis, Claudia Moreno. Understanding Gravitational Waves from Inspiral Binary Systems and its Detection.
