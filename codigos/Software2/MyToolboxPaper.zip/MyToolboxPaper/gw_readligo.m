function ligo = gw_readligo(RUN,IFO,Ni)
%
% read strain data and injection information from LIGO file
%
%   $Revision: 0.01 $  $Date: 2015/06/03 22:15:43 $
%   Designed by Javier M. Antelis & Claudia Moreno
%   $ gw_readligo.m $
%
% INPUT:
%    RUN       - 'S5' or 'S6'
%    IFO       - 'H1' or 'L1'
%    Ni        - scalar with the number of the file
%
% OUTPUT:
%    noise     - structure noise data





%% GET INJECTION INFORMATION

% Load injection data and filename con the Ni-th file
if     strcmp(RUN,'S5')
    ligo.injection     = gw_getinjectioninfoS5(IFO,Ni);
    ligo.path          = 'C:\_DataSets\Data_LIGOS5\';
    ligo.filename      = ligo.injection.filename;
    
elseif strcmp(RUN,'S6')
    ligo.injection     = gw_getinjectioninfoS6(IFO,Ni);
    ligo.path          = 'C:\_DataSets\Data_LIGOS6\';
    ligo.filename      = ligo.injection.filename;

else
    error('PILAS: Unknown LIGO run')
    
end



%% LOAD DATA

% Sampling frequency and period
ligo.ts                   = hdf5read([ligo.path ligo.filename],'/strain/Strain','Xspacing');
ligo.fs                   = 1/ligo.ts;
ligo.Npoints              = double(hdf5read([ligo.path ligo.filename],'/strain/Strain','Npoints'));
ligo.Tblock               = ligo.Npoints/ligo.fs;

% Get the start and end time of the data
ligo.gpsini               = double(hdf5read([ligo.path ligo.filename],'/strain/Strain','Xstart'));
ligo.gpsend               = ligo.gpsini + ligo.Tblock-1*ligo.ts;

% Read the strain values
ligo.strain               = hdf5read([ligo.path ligo.filename],'/strain/Strain');
ligo.timegps              = linspace(ligo.gpsini,ligo.gpsend,length(ligo.strain))';
ligo.timesec              = ligo.timegps - ligo.timegps(1);

% Plot strain data
if (0)
    figure(1), clf
    subplot(2,1,1), hold on
    plot(ligo.timegps,ligo.strain), line([ligo.injection.GPS ligo.injection.GPS],[-1e-10 1e-10],'Color',[1 0 0])
    xlabel('Time (gps)'), ylabel('strain'), title(['Start=' num2str(ligo.timegps(1)) ' | ' 'End=' num2str(ligo.timegps(end))  ' | ' 'Coal=' num2str(ligo.injection.GPS)])
    set(gca,'Xlim',[ligo.timegps(1) ligo.timegps(end)],'Ylim',[-1e-15 1e-15]), box on
    subplot(2,1,2), hold on
    plot(ligo.timesec,ligo.strain), line([ligo.injection.GPS ligo.injection.GPS]-ligo.gpsini,[-1e-10 1e-10],'Color',[1 0 0])
    xlabel('Time (s)'), ylabel('strain'), title(['Start=' num2str(ligo.timesec(1)) ' | ' 'End=' num2str(ligo.timesec(end))  ' | ' 'Coal=' num2str(ligo.injection.GPS-ligo.gpsini)])
    set(gca,'Xlim',[ligo.timesec(1) ligo.timesec(end)],'Ylim',[-1e-15 1e-15]), box on
end % if (1)



%% COMPUTE SEGMENTS INFORMATION

% Duration of the data segment and overlap (seconds)
ligo.segments.Twin        = 128;           % even and power of two
ligo.segments.Tove        = ligo.segments.Twin/2;

% Number of segments
ligo.segments.Nseg        = 2*(ligo.Tblock/ligo.segments.Twin)-1;

% Time ini and Time end of each segment (seconds)
Tini                      = (1:ligo.segments.Tove:ligo.Tblock-ligo.segments.Tove)';
Tend                      = Tini+ligo.segments.Twin-1;

% Sample ini and Sample end of each segment (sample)
Sini                      = (Tini-1)*ligo.fs+1;
Send                      = (Tend-0)*ligo.fs+0;

% Time and samples of each interval
ligo.segments.Tint        = [Tini Tend];
ligo.segments.Sint        = [Sini Send];

% Get segment where the GW was injected
tcoal                     = ligo.injection.GPS - ligo.gpsini;
d                         = ligo.segments.Tint - tcoal;
md                        = abs(d(:,1)+d(:,2));
[~, ligo.segments.seginj] = min(md);



%% INITIALIZE NFFT AND "injection" FIELD

ligo.NFFT                 = ligo.segments.Twin * ligo.fs;
ligo.injection.fs         = ligo.fs;
ligo.injection.NFFT       = ligo.NFFT;



%% VERIFICAR QUE EL GPS INJETION ESTE DENTRO DEL GET DE LOS DATOS LEIDOS

if ligo.injection.GPS-ligo.gpsini>0 && ligo.gpsend-ligo.injection.GPS>0
    % Todo bien
    fprintf('FINO: The strain data contains an injection\n')
else
    ligo %#ok<NOPRT>
    ligo.injection
    error('PILAS: GPSinjection is outside GPSdata')
end % if ligo.injection.GPS-ligo.gpsini>0 && ligo.gpsend-ligo.injection.GPS>0



%% CHECK WHETHER THE INKECTION WAS UNSUCESSFULL

if strcmp(ligo.injection.Log,'injection-compromised') || strcmp(ligo.injection.Log,'did-not-execute')
    error('pilas: injection compromised. not posible to evaluate cbc hardware injection')
end % if strcmp(ligo.injection.log,'injection-compromised') || strcmp(ligo.injection.log,'did-not-execute')


