function injection = gw_getinjectioninfoS5(INTERFEROMETER,Ni)
% 
% PILAS: se asume que el Ni injection information coincide con el Ni
% datafile contenido en el folder Data_LIGOS5


% Read injection information
[GPS,IFO,M1,M2,D,Log,Exp_SNR,Rec_SNR] = textread([INTERFEROMETER '_cleanlog_cbc.txt'],'%d %s %f %f %f %s %f %f',Ni);


% Get filenames
if     strcmp(INTERFEROMETER,'H1')
    hdf5Files   = dir(['C:\_DataSets\Data_LIGOS5\H-' INTERFEROMETER '*.hdf5']);
elseif strcmp(INTERFEROMETER,'L1')
    hdf5Files   = dir(['C:\_DataSets\Data_LIGOS5\L-' INTERFEROMETER '*.hdf5']);
end


% Save injection info
injection.GPS      = GPS(Ni,1);
injection.IFO      = IFO{Ni,1};
injection.M1       = M1(Ni,1);
injection.M2       = M2(Ni,1);
injection.D        = D(Ni,1);
injection.Log      = Log{Ni,1};
injection.Exp_SNR  = Exp_SNR(Ni,1);
injection.Rec_SNR  = Rec_SNR(Ni,1);
injection.filename = hdf5Files(Ni).name;

injection.PNorder  = 2.0; 


%%

% # GPS  IFO  M1  M2  Distance(Mpc)  Log  Exp_SNR  Rec_SNR 
% https://losc.ligo.org/archive/links/S5/H1/827303222/827303222/simple/






