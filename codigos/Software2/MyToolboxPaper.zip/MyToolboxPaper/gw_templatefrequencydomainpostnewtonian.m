function [hf , f] = gw_templatefrequencydomainpostnewtonian(cfg,prm,DeffMpc,fs,nfft,PN)
% Compute h(f) using the stationary phase aproximation



%% DEFINE PARAMETERS

% Get the number of points for the single-sided FFT
if mod(nfft,2) == 0
    % nfft is even
    nffthalf = nfft/2 +1;
else
    % nfft is odd
    nffthalf = (nfft+1)/2;
end

% Compute frequency vector
f        = linspace(0,fs/2,nffthalf)';



%% COMPUTE h(f)


% 1) Compute A_DeffMpc(f)
c1         = -sqrt(5./(24*pi));
c2         = (cfg.G*cfg.Msun/(cfg.c^2*cfg.megaparsec));
c3         = ((pi*cfg.G*cfg.Msun)/cfg.c^3)^(-1/6);
c4         = prm.Mchirp^(5./6);
A_DeffMpc  = c1*c2*c3*c4;


% 2) Compute v FindChirp paper  [Pag. 3 Equ. 3.4d]
v          = (cfg.G*2e30*prm.Mtotal*pi*f/cfg.c3).^(1/3);


% 3) Compute Psi(f)
if PN==2
    % Para 2PN FindChirp paper  [Pag. 3 Equ. 3.4c]
    t1         = ( 3715/756 + (55/9)*prm.eta );
    t2         = (16*pi);
    t3         = ( 15293365/508032 + (27145/504)*prm.eta + (3085/72)*prm.eta^2 );
    
    Psi        = 2*pi*f*0 - 2*prm.phio - pi/4 + (3/(128*prm.eta))*( ...
        (v.^-5) + (t1*v.^-3) - (t2*v.^-2) + (t3*v.^-1) );
    
    
elseif PN==3.5
    % Para 3.5PN FindChirp paper [Pag. 16 Equ. E.2]
    vo         = 1;
    gammaE     = 0.577216;
    k1         = (3715/756) + (55/9)*prm.eta;
    k2         = (16*pi);
    k3         = (15293365/508032) + (27145/504)*prm.eta + (3085/72)*prm.eta^2;
    k4         = ( (38645/756)-(65/9)*prm.eta ) * (1+3*log(v/vo)) * pi;
    k5         = ( (11583231236531/4694215680)  -  ((640/3)*pi^2) ...
        -  ((6848/21)*gammaE)  -  ((6848/21)*log(4*v)) ...
        + (((-15737765635/3048192)+(2255/1728)*pi^2)*prm.eta) ...
        + ((76055/1728)*prm.eta^2)  -  ((127825/1296)*prm.eta^3)  );
    k6         = ( (77096675/254016) + ((378515/1512)*prm.eta) - ((74045/756)*prm.eta^2) )*pi;
    
    Psi        = 2*pi*f*0 - 2*prm.phio - pi/4 + (3/128)*(1/prm.eta)*(v.^-5) ...
        .* ( 1 + k1*v.^2 - k2*v.^3 + k3*v.^4 + k4.*v.^5 + k5.*v.^6 + k6*v.^7 );
    
else
    error('PILAS: unknown Post-Newtonian correction')
    
end


% 4) Compute h(f)
hf         = (1/DeffMpc) * A_DeffMpc * (f.^(-7/6)) .* exp(-1i.*Psi);

% 4) Set to zero the response for frequencies outside the detector response
hf(f>prm.fisco) = 0;
hf(f<prm.flow)  = 0;
