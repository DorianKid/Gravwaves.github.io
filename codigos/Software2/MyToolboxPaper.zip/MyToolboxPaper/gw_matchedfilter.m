function [rho,sigma] = gw_matchedfilter(data,template,noise)

% Matched filter: multiply the data by the template and weighted by the PSD
integrand     = data.sf .* conj(template.sf) ./ noise.psd;

% Zero pad before IFFT
num_zeros     = length(data.st) - length(data.sf);
padded_int    = [integrand ; zeros(num_zeros,1)];

% Inverse Fourier Transform to get the matched filter result in time-domain
z             = 4 * ifft(padded_int);

% Compute sigma for normalization
% *******PILAS PERRO: ESTO SE PUEDE HACER FOR FUERRA DE ESTA FUNCION*******
kernal        = ((abs(template.sf)).^2) ./ noise.psd;
df            = noise.fpsd(2) - noise.fpsd(1);
sig_sqr       = 4*sum(kernal)*df;
sigma         = sqrt(sig_sqr);

% Calculate the SNR, rho, for each time offset
rho           = (abs(z)/sigma) .* data.inv_win;

% Plot for debugging
if (0)
    plot(data.t,rho)
end



