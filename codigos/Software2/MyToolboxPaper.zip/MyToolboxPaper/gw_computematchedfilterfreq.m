function matchedfilter = gw_computematchedfilterfreq(data,template,noise)
%
% compute matched filter output
% compute h(f) using the stationary phase aproximation
%
%   $Revision: 0.01 $  $Date: 2015/11/28 09:26:32 $
%   Designed by Javier M. Antelis & Claudia Moreno
%   $ gw_computematchedfilterfreq.m $
%
% INPUT:
%    data      - structure with data segment
%    template  - structure with template
%    noise     - structure with noise
%
% OUTPUT:
%    matchedfilter - structure matched filter output



%% APPLY MATCHED FILTER

% Initiate time
tic

% Status flag
matchedfilter.dataflag                     = noise.dataflag;

% Save time
matchedfilter.t                            = data.t;

% Compute the matched filter output
[matchedfilter.rho,matchedfilter.sigma]    = gw_matchedfilter(data,template,noise);


% Compute the expected SNR, using the known distance in Mpc
matchedfilter.SNRexp                       = matchedfilter.sigma/template.prm.DMpc;

% Find the value and the time of the maximum SNR
[matchedfilter.SNRpre, ind ]               = max(matchedfilter.rho);
matchedfilter.gpscoal                      = data.t(ind);

% Detection FLAG
if abs(matchedfilter.gpscoal-data.injection.GPS)<=0.1*template.prm.Tchirp
    matchedfilter.detection                = 1;
    fprintf('! DETECTION � \n')
else
    matchedfilter.detection                = 0;
    fprintf('! NO DETECTION � \n')
end

% Print results
fprintf('SNRexpected  = %3.1f \n',matchedfilter.SNRexp)
fprintf('SNRpredicted = %3.1f \n',matchedfilter.SNRpre)

% Save computing time
matchedfilter.tsim                         = toc;
