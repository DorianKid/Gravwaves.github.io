function noise = gw_computenoise(ligo)
%
% compute matched filter output
% compute h(f) using the stationary phase aproximation
%
%   $Revision: 0.01 $  $Date: 2015/11/20 17:23:15 $
%   Designed by Javier M. Antelis & Claudia Moreno
%   $ gw_computenoise.m $
%
% INPUT:
%    ligo      - structure with ligo data and info
%
% OUTPUT:
%    noise     - structure noise data



%% COMPUTE NOISE

% Initialize noise structure
noise.st                   = [];
noise.t                    = [];
noise.sf                   = [];
noise.f                    = [];
noise.psd                  = [];
noise.fpsd                 = [];

    % ****************************************************
    % 1) If there are not NaN's values in the strain data:
    % ****************************************************
if ~isnan(sum(ligo.strain))
    fprintf('FINO: The strain data is OK\n')
    
    if  isfield(ligo,'injection')
        % Compute noise PSD
        [noise.psd, noise.fpsd]    = pwelch(ligo.strain,hann(ligo.NFFT),ligo.NFFT/2,ligo.NFFT,ligo.fs);
    	% Save noise signal
        noise.st                   = ligo.strain;
        noise.t                    = ligo.timegps;
        
        % Status flag
        noise.dataflag = 1; % The strain data is OK
        
    else
        % Compute noise PSD1
        noise.psd1NFFT                    = 4*ligo.fs;
        [noise.psd1data, noise.psd1freq]  = pwelch(ligo.strain,blackman(noise.psd1NFFT),noise.psd1NFFT/2,noise.psd1NFFT,ligo.fs);
        
        % Obtener vector de frecuencias
        deltaf         = 1/(length(ligo.strain)/ligo.fs);
        datafreqhalf1  = ((0:deltaf:(ligo.fs/2)-deltaf))';
        datafreqhalf2  = (-ligo.fs/2:deltaf:-deltaf)';
        noise.fpsd     = [datafreqhalf1 ; datafreqhalf2];
        
        % Compute noise PSD
        noise.psd      = interp1(noise.psd1freq,noise.psd1data,abs(noise.fpsd));
        
        
    end % if  isfield(ligo,'injection')
    
    % ************************************************
    % 2) If there are NaN's values in the strain data:
    % ************************************************
else
    fprintf('PILAS: The strain data contains NaN values\n')
    
    % Get the strain data segment where the injection is located
    ind    = ligo.segments.Sint(ligo.segments.seginj,1):ligo.segments.Sint(ligo.segments.seginj,2);
    strain = ligo.strain(ind);
    
    % Status flag
    noise.dataflag = 2; % The strain contains NaN values
    
        % ------------------------------------------------------------
        % 2a) If there are not NaN's values in the strain data segment:
        % ------------------------------------------------------------
    if ~isnan(sum(strain))
        fprintf('FINO: The strain data segment (that includes the injection) is OK\n')
        
        % Compute noise PSD
        [noise.psd, noise.fpsd]     = pwelch(strain,hann(ligo.NFFT/4),ligo.NFFT/8,ligo.NFFT,ligo.fs);
        
        % Save noise signal
        noise.st                   = ligo.strain(ind);
        noise.t                    = ligo.timegps(ind);
        
        
        % ------------------------------------------------------------
        % 2b) If there are NaN's values in the strain data segment:
        % ------------------------------------------------------------
    else
        error('PILAS: The strain data segment (that includes the injection) contains NaN values')
    end % if ~isnan(sum(strain))
    
end % if ~isnan(sum(ligo.strain))


% Plot noise PSD
if (0)
    figure
    plot(noise.fpsd,noise.psd,'k','LineWidth',2), hold on
    xlabel('Frequency   [Hz]'), ylabel('Spectral Power [Hz^{-1/2}]'), title('P_{ww}(f): noise PSD')
    set(gca,'XLim',[1 ligo.fs/2],'XScale','Log','YScale','Log','FontSize',10)
    set(gca,'YLim',[1e-46 1e-30])
    grid on, box on
end % if (1)

