function template = gw_computetemplatepostnewtonian(M1,M2,D,PNorder,fs,NFFT)
%
% compute h(t) using 2PN aproximation
% compute h(f) using the stationary phase aproximation
%
%   $Revision: 0.01 $  $Date: xxxx/xx/xx xx:xx:xx $
%   Designed by Javier M. Antelis & Claudia Moreno
%   $ gw_computetemplatepostnewtonian.m $
%
% INPUT:
%    M1      - Mass of object 1
%    M2      - Mass of object 2
%    D       - Effective distance of the binary system
%    PNorder - Post Newtoniar order
%    fs      - Sampling frequency
%    NFFT    - Number of point for the FFT
%
% OUTPUT:
%    template - structure with template in the time and frequency domain



%% COMPUTE TEMPLATE

% Initialize temp structure
template.st                = [];
template.t                 = [];
template.sf                = [];
template.f                 = [];
template.psd               = [];
template.fpsd              = [];

% Compute constants
template.cfg               = gw_constants;

% Compute parameters for the template
template.prm               = gw_parameterspostnewtonian(template.cfg,M1,M2,D,PNorder);

% Compute template in the time domain
GW                         = gw_templatetimedomainpostnewtonian(template.cfg,template.prm,fs,NFFT,PNorder);
template.st                = GW.ht;
template.t                 = GW.t;
template.fs                = fs;

% Compute template single-sided FFT directly in the frequency domain (D=1Mpc)
[template.sf, template.f]  = gw_templatefrequencydomainpostnewtonian(template.cfg,template.prm,1,fs,NFFT,PNorder);

% Plot template FFT
if (0)
    figure, hold on
    plot(GW.f ,abs(GW.hf),'k','LineWidth',1,'Color',[0.83 0.82 0.78])
    plot(template.f,abs(template.sf),'k','LineWidth',2)
    grid on, box on
    xlabel('Frequency   [Hz]'), ylabel('Spectral Power [Hz^{-1/2}]'), title('h(f): Template sigle-sided FFT'), legend('FFT','SPA')
    set(gca,'XLim',[1 template.fs/2],'XScale','Log','YScale','Log','FontSize',10)
    set(gca,'YLim',[1e-24 1e-19])
end


