function GW = gw_templatetimedomainpostnewtonian(cfg,prm,fs,nfft,PN)


%% SECOND ORDER POST NEWTONIAN SOLUTION

if PN==2
    % Do nothing
else 
    error('PILAS: trabaje perrito')
end

%% Define parameters

% Convert masses (originally in units of solas mass) to Kg
prm.m1         = prm.m1      *cfg.Msun;
prm.m2         = prm.m2      *cfg.Msun;
prm.Mtotal     = prm.Mtotal  *cfg.Msun;
prm.mu         = prm.mu      *cfg.Msun;
prm.Mchirp     = prm.Mchirp  *cfg.Msun;

% Initialize output variable
GW.Tchirp    = prm.Tchirp;
GW.fs        = fs;
GW.ts        = 1/GW.fs;
GW.N         = floor(GW.Tchirp * GW.fs);
GW.freso     = 1/(GW.N*GW.ts);
GW.t         = linspace(0,GW.Tchirp-(1*GW.ts),GW.N)'; % (recall that coalescence occurrs at t=0)



%% Compute Theta(t)

GW.Thetat    = ((cfg.c3*prm.eta)/(5*cfg.G*prm.Mtotal)) * (prm.tc-GW.t);


%% Compute f(t). Classical Newtonian solution

GW.ft0       = (cfg.c3/(8*pi*cfg.G*prm.Mtotal)) * GW.Thetat.^(-3/8);


%% Compute phi(t). Classical Newtonian solution

GW.phit0     = (-16*pi/5) * GW.ft0 .* (prm.tc-GW.t) + prm.phio;


%% Compute f(t). Second-post-Newtonian order

% From http://arxiv.org/abs/gr-qc/9602024v1 [pag. 9 equ. 8]
t1           = GW.Thetat.^(-3/8); k1 = 1;
t2           = GW.Thetat.^(-5/8); k2 = (743/2688) + (11/32)*prm.eta;
t3           = GW.Thetat.^(-3/4); k3 = -3*pi/10;
t4           = GW.Thetat.^(-7/8); k4 = (1855099/14450688) + (56975/258048)*prm.eta + (371/2048)*prm.eta^2;
GW.ft        = ( (cfg.c3/(8*cfg.G*prm.Mtotal)) *( k1*t1 + k2*t2 + k3*t3 + k4*t4 ) ) / (1*pi);


%% Compute phi(t). Second-post-Newtonian order

t1           = GW.Thetat.^(5/8); k1 = 1;
t2           = GW.Thetat.^(3/8); k2 = (3715/8064) + (55/96)*prm.eta;
t3           = GW.Thetat.^(1/4); k3 = -3*pi/4;
t4           = GW.Thetat.^(1/8); k4 = (9275495/14450688) + (284875/258048)*prm.eta + (1855/2048)*prm.eta^2;
GW.phit      = prm.phio - (1/prm.eta)*( k1*t1 + k2*t2 + k3*t3 + k4*t4 );
GW.phit      = 2*GW.phit;
clear ans k1 t1 k2 t2 k3 t3 k4 t4


%% Compute f(t). Three and a half-post-Newtonian order


%% Compute phi(t). Three and a half-post-Newtonian order

%% Compute h+(t) and hx(t). Second-post-Newtonian order

hct          = (2/cfg.c2) * (prm.mu/cfg.Msun) * (pi*cfg.G*prm.Mtotal*GW.ft).^(2/3) .* cos(GW.phit-prm.phio);
hst          = (2/cfg.c2) * (prm.mu/cfg.Msun) * (pi*cfg.G*prm.Mtotal*GW.ft).^(2/3) .* sin(GW.phit-prm.phio);

GW.hmt       = - (1*cfg.G*cfg.Msun/(cfg.c2*prm.D)) * (2*prm.cosiota2) .* hct;
GW.hxt       = - (2*cfg.G*cfg.Msun/(cfg.c2*prm.D)) * (1*prm.cosiota1) .* hst;
clear ans hct hst


%% Compute A(t)

GW.At        = -(2*cfg.G*prm.mu/cfg.c4) * (pi*cfg.G*prm.Mtotal*GW.ft).^(2/3);
GW.At        = GW.At / prm.Deff;


%% Compute h(t)

GW.ht        = GW.At .* cos(GW.phit - prm.theta);


%% Compute h(f)

% Define nfft
if isempty(nfft)
    GW.nfft      = length(GW.ht);
else
    GW.nfft      = nfft;
end

% Full-sided FFT
GW.hf            = fft(GW.ht,GW.nfft)/fs;

% Single-Sided FFT
if mod(GW.nfft,2) == 0
    % nfft is even
    nffthalf = GW.nfft/2 +1;
else
    % nfft is odd
    nffthalf = (GW.nfft+1)/2;
end
GW.hf(nffthalf+1:end) = [];
GW.hf                 = 2*GW.hf;

GW.f                  = linspace(0,GW.fs/2,nffthalf)';
