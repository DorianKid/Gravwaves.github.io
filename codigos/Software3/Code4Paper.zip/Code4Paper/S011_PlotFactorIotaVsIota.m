%% INITIALIZE
clearvars
close all
clc



%% DO THE CALCULATIONS

% --------------------------------------
% Define iota
iotagrag  = -180:10:180;
iota      = iotagrag*pi/180;

% --------------------------------------
% Compute f(iota)
hpiota   = (1+(cos(iota)).^2)/2;
hciota   = cos(iota);
hxiota   = sin(2*iota)/2;
hyiota   = sin(iota);
hbiota   = (sin(iota).^2)/2;
hliota   = (sin(iota).^2)/sqrt(2);

% --------------------------------------
% Define colors
c =[[0      0.4470 0.7410];...
    [0.8500 0.3250 0.0980];...
    [0.9290 0.6940 0.1250];...
    [0.4940 0.1840 0.5560];...
    [0.4660 0.6740 0.1880];...
    [0.3010 0.7450 0.9330];...
    [0.6350 0.0780 0.1840]];

% --------------------------------------
% Plot f(iota) vs. iota
figure(2), clf, hold on
plot(iota,hpiota,'.-','MarkerSize',14,'Color',c(1,:),'MarkerFaceColor',c(1,:))
plot(iota,hciota,'o-','MarkerSize',5 ,'Color',c(2,:),'MarkerFaceColor',c(2,:))
plot(iota,hxiota,'>-','MarkerSize',5 ,'Color',c(3,:),'MarkerFaceColor',c(3,:))
plot(iota,hyiota,'<-','MarkerSize',5 ,'Color',c(4,:),'MarkerFaceColor',c(4,:))
plot(iota,hbiota,'s-','MarkerSize',5 ,'Color',c(5,:),'MarkerFaceColor',c(5,:))
plot(iota,hliota,'d-','MarkerSize',5 ,'Color',c(6,:),'MarkerFaceColor',c(6,:))
b=legend('$g_{+}(\iota)=(1+\cos^2\iota)/2$','$g_{\times}(\iota)=\cos(\iota)$','$g_{x}(\iota)=\sin(2\iota)/2$','$g_{y}(\iota)=\sin(\iota)$','$g_{b}(\iota)=\sin^2\iota/2$','$g_{l}(\iota)=\sin^2\iota/\sqrt2$',...
    'Location','SouthWest','Interpreter','Latex','FontSize',10,'Color','none','EdgeColor','none');
set(b,'Position',[0.4565    0.1159    0.3124    0.2465])
axis([-pi pi -1.1 1.1])
ylabel('g(\iota)'), xlabel('\iota')
box on, grid on
set(gca,'FontSize',12)
set(gca,'XTick',[-pi -pi/2 0 pi/2 pi],'XTickLabel',{'-\pi','-\pi/2','0','\pi/2','\pi'})

% --------------------------------------
% Save plot
if (0)
    filename = ['Figures/S011_PlotFactorIotaVsIota/' 'FactorIota'];
    saveas(gcf,filename,'png')
    saveas(gcf,filename,'eps')
end






