function cfg = gwpol_constants()
%
% create constants for GW detection
%
% Copyright (C) 2015-2020
%   $Revision: 0.01 $  $Date: 2021/12/17 13:24:09 $
%   Designed by Javier M. Antelis & Claudia Moreno
%   $ gw_constants.m $
%
% INPUT:
%    fs       - sampling frequency
%
% OUTPUT:
%    cfg      - configuration variable with all constants
%


%% CONSTANTS

% Gravitational constant (N�(m/kg)^2) or? (m^3/(kg*s^2))
cfg.G           = 6.67e-11;   % 6.67384e-11 

% Light velocity (m/s)
cfg.c           = 3e8;        % 2.99792458e8
cfg.c2          = cfg.c^2;
cfg.c3          = cfg.c^3;
cfg.c4          = cfg.c^4;

% Solar mass (Kg)
cfg.Msun        = 2e30;       % 1.98982e30

% Parsec (m)
cfg.parsec      = 3e16;       % 3.0856775807e16
cfg.megaparsec  = 3e22;       % 3.0856775807e22



