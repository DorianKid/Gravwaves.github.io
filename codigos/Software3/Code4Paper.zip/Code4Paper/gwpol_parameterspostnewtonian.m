function prm = gwpol_parameterspostnewtonian(cfg,m1,m2,DMpc,PNorder,iota)
%
% define parameters for GW detection
%
%   $Revision: 0.01 $  $Date: 2021/21/01 09:44:54 $
%   Designed by Javier M. Antelis & Claudia Moreno
%   $ gw_parameterspostnewtonian.m $
%
% INPUT:
%    cfg      - structure with constants used for GW detection
%    m1       - mass of object 1 in the companion (units of solar masses)
%    m2       - mass of object 2 in the companion (units of solar masses)
%    DMpc     - distance between the source and the detector (in Mpc)
%
% OUTPUT:
%    prm      - configuration variable with all parameters
% 
% NOTE: an inspiral waveform is described by the following nine parameters  
% tc               the end time of the inspiral
% m1               the mass of the first binary component
% m2               the mass of the second binary component
% iota             the inclination angle of the binary
% phio             the oribital phase of the binary
% psi              the polarization angle of the binary
% (theta,varphi)   the sky coordinates of the binary
% r                the distance to the binary


%% PARAMETERS

% Mass of the binaries (units of solar mass)
prm.m1          = m1;
prm.m2          = m2;

% Total mass of the two companions (units of solar mass)
prm.Mtotal      = prm.m1 + prm.m2;

% Reduced mass (units of solar mass)
prm.mu          = (prm.m1*prm.m2)/prm.Mtotal;

% Ratio reduced mass and total mass or symmetric mass ratio (dimenssionless)
prm.eta         = prm.mu/prm.Mtotal; % or m1*m2/Mtotal^2

% Chirp mass (units of solar mass)
prm.Mchirp      = prm.mu^(3/5) * prm.Mtotal^(2/5); % or ang_mom = eta^(3./5)*Mtot

% Chirp minimum and maximum frequencies (Hz)
prm.flow        = 30;
prm.fisco       = cfg.c3/(6*sqrt(6)*pi*cfg.G*cfg.Msun*prm.Mtotal);

% Number of cycles (dimenssionless)
prm.Ncyc        = (1/(32*pi^(8/3))) * ((cfg.G*prm.Mchirp*cfg.Msun/cfg.c3)^(-5/3)) * (prm.flow^(-5/3) - prm.fisco^(-5/3));

% Save PostNewtonian order
prm.PNorder       = PNorder;
if     prm.PNorder==0
    prm.PNorderSTR = 'PN0';
elseif prm.PNorder==2
    prm.PNorderSTR = 'PN2';
elseif prm.PNorder==3.5
    prm.PNorderSTR = 'PN3p5';
end

% Chirp duration (s). DE DONDE SALIERON ESTAS ECUACIONES??????
% https://arxiv.org/pdf/0903.0338.pdf
% Chirp times: PN contributions at different orders to the duration of a signal starting from a time when the instantaneous GW frequency has a fiducial value fL to a time when the GW frequency formally diverges and system coalesces. 
% For instance, the chirp times tau0 and tau3 at
% Newtonian and 1.5 PN orders, respectively, are
xlow        = ( (cfg.G*prm.Mtotal*cfg.Msun/cfg.c3)*(pi*prm.flow) )^(1/3);
tau0        = ( 5/(256*pi*prm.eta*prm.flow) ) * (xlow)^(-5);
tau1        = ( 1/(8*prm.eta*prm.flow) ) * (xlow)^(-2);

gammaE          = 0.577216;

xlow_8          = xlow^(-8);
xlow_6          = (743/252 + (11/3)*prm.eta) * (xlow^(-6));
xlow_5          = - (32*pi/5) * (xlow^(-5));
xlow_4          = (3058673/508032 + (5429/504)*prm.eta + (617/72)*prm.eta^2) * (xlow^(-4));
xlow_3          = ( (13/3)*prm.eta - (7729/252)) * pi * (xlow^(-3));
xlow_2          = ( ...
    ( (6848*gammaE/105)-(10052469856691/23471078400)+(128*(pi^2)/3) ) ...
    +   ( ( (3147553127/3048192) - (451*(pi^2)/12) ) *prm.eta ) ...
    -   ( (15211/1728) *prm.eta^2 ) ...
    +   ( (25565/1296) *prm.eta^3 ) ...
    +   ( (6848/105) *log(4*xlow) ) ...
    ) * (xlow^(-2));
xlow_1          = ( (14809/378)*prm.eta^2 - (75703/756)*prm.eta - 15419335/127008 ) * pi * (xlow^(-1));

if  prm.PNorder==0       % Bueno
    prm.Tchirp        = tau0;
elseif prm.PNorder==1    % Bueno
    prm.Tchirp      = tau0+tau1;
elseif  prm.PNorder==1.5
    prm.Tchirp      = tau0+tau1;
elseif  prm.PNorder==2   % Bueno
    prm.Tchirp      = (5/(256*prm.eta)) * (cfg.G*prm.Mtotal*cfg.Msun/cfg.c3) * ( xlow_8 + xlow_6 + xlow_5 + xlow_4 );
elseif prm.PNorder==2.5
    prm.Tchirp      = (5/(256*prm.eta)) * (cfg.G*prm.Mtotal*cfg.Msun/cfg.c3) * ( xlow_8 + xlow_6 + xlow_5 + xlow_4 );
elseif prm.PNorder==3
    prm.Tchirp      = (5/(256*prm.eta)) * (cfg.G*prm.Mtotal*cfg.Msun/cfg.c3) * ( xlow_8 + xlow_6 + xlow_5 + xlow_4 + xlow_3 + xlow_2 + xlow_1);
elseif prm.PNorder==3.5  % Bueno
    prm.Tchirp      = (5/(256*prm.eta)) * (cfg.G*prm.Mtotal*cfg.Msun/cfg.c3) * ( xlow_8 + xlow_6 + xlow_5 + xlow_4 + xlow_3 + xlow_2 + xlow_1);
else
    error('PILAS: arregle esto perro')
end


clear ans xlow xlow_8 xlow_6 xlow_5 xlow_4 xlow_3 xlow_2 xlow_1

%% DETECTOR RESPONSE

% % Inclination angle of the binary (rad)
prm.iota        = iota;
prm.iotadegree  = prm.iota*(180/pi);
prm.cosiota1    = cos(prm.iota);
prm.cosiota2    = (1+(cos(prm.iota))^2)/2;

% % Detector or antenna pattern/response functions
% prm.Dtheta   = ;
% prm.Dvarphi  = ;
% prm.Dpsi     = ;
% prm.Fm       = -0.5*(1+cos(prm.Dtheta)^2)*cos(2*prm.Dvarphi)*cos(2*prm.Dpsi) - cos(prm.Dtheta)*cos(2*prm.Dvarphi)*sin(2*prm.Dpsi);
% prm.Fx       = +0.5*(1+cos(prm.Dtheta)^2)*cos(2*prm.Dvarphi)*sin(2*prm.Dpsi) - cos(prm.Dtheta)*sin(2*prm.Dvarphi)*cos(2*prm.Dpsi);
% if (0)
%     % plot detector response
% end

% % Distance between the source and the detector
prm.D           = DMpc*cfg.megaparsec;     % (in m)
prm.DMpc        = DMpc;                    % (in Mpc)

% Effective distance between the source and the detector
% prm.Deff        = prm.D * ( (prm.Fm^2).*prm.cosiota2^2 + (prm.Fx^2).*prm.cosiota1^2 )^(-1/2);
% prm.Deff        = prm.D;                   % (in m)
% prm.DeffMpc     = prm.Deff/cfg.megaparsec; % (in Mpc)

% Amplitude parameters for the book of Michele Maggiori
% prm.Am          = (4/prm.D) * ((prm.G*prm.Mchirp/c2)^(5/3)) * prm.Fm * prm.cosiota2;
% prm.Ax          = (4/prm.D) * ((prm.G*prm.Mchirp/c2)^(5/3)) * prm.Fx * prm.cosiota1;
% prm.A           = (prm.Am.^2 + prm.Ax.^2).^(1/2);
% prm.A           = -0.5 * (4/prm.Deff) * ((cfg.G*prm.Mchirp*cfg.Msun/cfg.c2)^(5/3));
% prm.MK          = cfg.G*prm.Mtotal*cfg.Msun/cfg.c3;



%% INFORMATION FOR THE TIME-RESOLVED TEMPLATE

%*******************
% Coalescence time
prm.tc          = prm.Tchirp; % prm.t(end);
% Coalescence phase 
prm.phic        = 0;


%*******************
% Termination time  (the time at the detector at which the coalescence occurs, i.e., the detector time when the gravitational wave frequency, according to restricted post-Newtonian approximation, becomes infinite)
prm.to          = prm.tc;
% Termination phase 
prm.theta       = 0; % prm.theta       = atan((prm.Fx*prm.cosiota1)/(prm.Fm*prm.cosiota2)); %
prm.phio        = 0.5*(2*prm.phic - prm.theta); 






