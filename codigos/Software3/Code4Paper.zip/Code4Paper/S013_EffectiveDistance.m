%% INITIALIZE
clearvars
close all
clc

% --------------------------------------
% Save figures
DoSave = 0;


%% COMPUTE ANTENNA PATTERN 

% --------------------------------------
% Define parameters
iotadegree    = 60;
iota          = iotadegree*(pi/180);    % Angle iota [-pi,pi] (rad)
theta         = linspace(0,1*pi,100);   % Ranges from 0 to pi
phi           = linspace(0,2*pi,100);   % Ranges from 0 to 2pi

% Compute grid for theta and phi
[theta1,phi1] = meshgrid(theta,phi);

% --------------------------------------
% Compute antenna pattern: F+, Fc, Fx, Fy, Fb, Fl
Fp            = 0.5*(1+cos(theta1).^2).*cos(2*phi1)*cos(2*iota) - cos(theta1).*sin(2*phi1)*sin(2*iota);
Fc            = 0.5*(1+cos(theta1).^2).*cos(2*phi1)*sin(2*iota) - cos(theta1).*sin(2*phi1)*cos(2*iota);
Fx            = -sin(theta1) .* (cos(theta1).*cos(2*phi1).*cos(iota)-sin(2*phi1).*sin(iota));
Fy            = -sin(theta1) .* (cos(theta1).*cos(2*phi1).*sin(iota)+sin(2*phi1).*cos(iota));
Fb            = -0.5 .* sin(theta1).^2 .* cos(2*phi1);
Fl            = -Fb;

% --------------------------------------
% Ajuste en thetha
% theta1        = pi/2 - theta1;



%% MAGNITUDE

% --------------------------------------
% Compute magnitude of the antenna pattern
K_Fp          = (Fp.^2) .* ( ( (1+cos(iota).^2) ).^2 ) /4;
K_Fc          = (Fc.^2) .* cos(iota).^2;
K_Fx          = (Fx.^2) .* (sin(2*iota).^2)/4;
K_Fy          = (Fy.^2) .* sin(iota).^2;
K_Fb          = (Fb.^1) .* (sin(iota).^2)/2;
K_Fl          = (Fl.^1) .* (sin(iota).^2)/sqrt(2);

Deff_pc       = ( 1./sqrt( K_Fp + K_Fc ) );
%Deff_pcxybl   = ( (1./( sqrt(K_Fp + K_Fc) + sqrt(K_Fx+K_Fy) ))  +  (K_Fb+K_Fl) );
% Deff_pcxybl   = ( ( 1./( sqrt(K_Fp+K_Fc) + sqrt(K_Fx+K_Fy) + (K_Fb+K_Fl) ) ) );
Deff_pcxybl   = ( (sqrt(K_Fp+K_Fc)+sqrt(K_Fx+K_Fy)+(K_Fb+K_Fl)).^(-1) );


% -------------------------------
% Plot Deff for Fp and Fc

% % Tipo 1
% figure
% pcolor(phi*180/pi,theta*180/pi,Deff_pc)
% shading interp
% box on, axis on, axis square
% colorbar
% set(gca,'Xtick',0:90:360,'Ytick',0:45:180)
% title('$1/\sqrt{ F_{+}^{2}(\theta,\phi) \cdot g_{+}(\iota) + F_{\times}^{2}(\theta,\phi)  \cdot g_{\times}(\iota) }$','Interpreter','Latex','FontSize',10)
% % title('$log_{10} (1/\sqrt{ F_{+}^{2}(\theta,\phi) \cdot g_{+}(\iota) + F_{\times}^{2}(\theta,\phi)  \cdot g_{\times}(\iota) } )$','Interpreter','Latex','FontSize',10)
% xlabel('\phi (deg)','FontSize',16)
% ylabel('\theta (deg)','FontSize',16)
% if DoSave==1
%     filename = ['EffDis_' 'Ten' '_iota' num2str(iotadegree)];
%     saveas(gcf,['Figures/S013_EffectiveDistance/' filename],'png')
%     saveas(gcf,['Figures/S013_EffectiveDistance/' filename],'eps')
% end


% -------------------------------
% Plot Deff for Fp and Fc

% Tipo 1
figure
pcolor(phi*180/pi,theta*180/pi,Deff_pcxybl)
shading interp
box on, axis on, axis square
colorbar
set(gca,'FontSize',14)
set(gca,'Xtick',0:90:360,'Ytick',0:45:180)
%title('$1/ \{ \sqrt{ F_{+}^{2} \cdot g_{+}(\iota) + F_{\times}^{2} \cdot g_{\times}(\iota) } + \sqrt{ F_{x}^{2} \cdot g_{x}(\iota) + F_{y}^{2} \cdot g_{y}(\iota) } + F_{b}^{} \cdot g_{b}(\iota) + F_{l}^{} \cdot g_{l}(\iota) \}  $','Interpreter','Latex','FontSize',10)
% title('$ ( \sqrt{ F_{+}^{2} \cdot g_{+}(\iota) + F_{\times}^{2} \cdot g_{\times}(\iota) } + \sqrt{ F_{x}^{2} \cdot g_{x}(\iota) + F_{y}^{2} \cdot g_{y}(\iota) } + F_{b}^{} \cdot g_{b}(\iota) + F_{l}^{} \cdot g_{l}(\iota) )^{-1}  $','Interpreter','Latex','FontSize',10)
xlabel('$\varphi$ (deg)','FontSize',18,'Interpreter','Latex')
ylabel('$\theta$ (deg)','FontSize',18,'Interpreter','Latex')
if DoSave==1
    filename = ['EffDis_' 'TenAndTenWithNonten' '_iota' num2str(iotadegree)];
    saveas(gcf,['Figures/S013_EffectiveDistance/' filename],'png')
    saveas(gcf,['Figures/S013_EffectiveDistance/' filename],'eps')
end