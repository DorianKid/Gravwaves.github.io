function GW = gwpol_templatetimedomainpostnewtonian_v2(cfg,prm,fs,PN,doplot)
% S002_ComparePNorder
% PN=prm.PNorder;
% fs=;
% doplot=0;




%% 1) DEFINE PARAMETERS

% Convert masses (originally in units of solas mass) to Kg
prm.m1         = prm.m1     * cfg.Msun;
prm.m2         = prm.m2     * cfg.Msun;
prm.Mtotal     = prm.Mtotal * cfg.Msun;
prm.mu         = prm.mu     * cfg.Msun;
prm.Mchirp     = prm.Mchirp * cfg.Msun;

% Initialize output variable
GW.Tchirp      = prm.Tchirp;
GW.fs          = fs;
GW.ts          = 1/GW.fs;
GW.N           = floor(GW.Tchirp * GW.fs);
GW.freso       = 1/(GW.N*GW.ts);
GW.t           = linspace(0,GW.Tchirp-(1*GW.ts),GW.N)'; % (recall that coalescence occurrs at t=0)



%% 2) COMPUTE $\Theta(t)$

% Libro Magiore [Pag. 291, Equ. 5.242] or Thesis machos [Pag. 36, Equ. 2.99]
GW.Thetat      = ((cfg.c3*prm.eta)/(5*cfg.G*prm.Mtotal)) * (prm.tc-GW.t);



%% 3) COMPUTE "ORBITAL" PHASE AND FREQUENCY

% -----------------------------------
% Initialize
X.P           = [];
X.W           = [];
X.F           = [];

% -----------------------------------
% Terms for 0 PN
P.k0          = 1; 
P.t0          = GW.Thetat.^(5/8);
X.P(:,1)      = P.k0*P.t0;

W.k0          = 1; 
W.t0          = GW.Thetat.^(-3/8);
X.W(:,1)      = W.k0*W.t0;

% -----------------------------------
% Terms for 1 PN
P.k1          = (3715/8064) + (55/96)*prm.eta; 
P.t1          = GW.Thetat.^(3/8);
X.P(:,2)      = P.k0*P.t0 + P.k1*P.t1;

W.k1          = (743/2688) + (11/32)*prm.eta;
W.t1          = GW.Thetat.^(-5/8); 
X.W(:,2)      = W.k0*W.t0 + W.k1*W.t1;

% -----------------------------------
% Terms for 1.5 PN
P.k15         = -3*pi/4;
P.t15         = GW.Thetat.^(1/4);
X.P(:,3)      = P.k0*P.t0 + P.k1*P.t1 + P.k15*P.t15;

W.k15         = -3*pi/10;
W.t15         = GW.Thetat.^(-3/4); 
X.W(:,3)      = W.k0*W.t0 + W.k1*W.t1 + W.k15*W.t15;

% -----------------------------------
% Terms for 2 PN
P.k2          = (9275495/14450688) + (284875/258048)*prm.eta + (1855/2048)*prm.eta^2;
P.t2          = GW.Thetat.^(1/8); 
X.P(:,4)      = P.k0*P.t0 + P.k1*P.t1 + P.k15*P.t15 + P.k2*P.t2;

W.k2          = (1855099/14450688) + (56975/258048)*prm.eta + (371/2048)*prm.eta^2;
W.t2          = GW.Thetat.^(-7/8); 
X.W(:,4)      = W.k0*W.t0 + W.k1*W.t1 + W.k15*W.t15 + W.k2*W.t2;

% -----------------------------------
% Terms for 2.5 PN
P.Thetat_0    = GW.Thetat(1);

P.k25         = ( (-38645/172032) + (65/2048)*prm.eta ) * pi;
P.t25         = 1*log(GW.Thetat/P.Thetat_0);
X.P(:,5)      = P.k0*P.t0 + P.k1*P.t1 + P.k15*P.t15 + P.k2*P.t2 + P.k25*P.t25;

W.k25         = ( (-7729/21504) + (13/256)*prm.eta ) * pi;
W.t25         = 1*GW.Thetat.^(-1);
X.W(:,5)      = W.k0*W.t0 + W.k1*W.t1 + W.k15*W.t15 + W.k2*W.t2 + W.k25*W.t25;

% -----------------------------------
% Terms for 3 PN
P.C           = 0.577;

P.k3          = ( ...
    + (831032450749357/57682522275840) ...
    - ((53/40)*pi^2) ...
    - (107/56)*P.C ...
    + (107/448)*log(GW.Thetat/256) ...
    + ( (-123292747421/4161798144)+(2255/2048)*pi^2 )*prm.eta ... % Magiori: 126510089885; Blanket: 123292747421
    + (154565/1835008)*prm.eta.^2 ...
    - (1179625/1769472)*prm.eta.^3 ...
    );
P.t3          = GW.Thetat.^(-1/8);
X.P(:,6)      = P.k0*P.t0 + P.k1*P.t1 + P.k15*P.t15 + P.k2*P.t2 + P.k25*P.t25 + P.k3.*P.t3;

W.k3          = -(1/5)*( ...
    + (831032450749357/57682522275840) ...
    - ((53/40)*pi^2) ...
    - (107/56)*P.C ...
    + (107/448)*log(GW.Thetat/256) ...
    + ( (-123292747421/4161798144)+(2255/2048)*pi^2 )*prm.eta ...
    + (154565/1835008)*prm.eta.^2 ...
    - (1179625/1769472)*prm.eta.^3 ...
    - (107/56) ...
    );
W.t3          = GW.Thetat.^(-9/8);
X.W(:,6)      = W.k0*W.t0 + W.k1*W.t1 + W.k15*W.t15 + W.k2*W.t2 + W.k25*W.t25 + W.k3.*W.t3;

% -----------------------------------
% Terms for 3.5 PN
P.k35         = ( (188516689/173408256) + (488825/516096)*prm.eta - (141769/516096)*prm.eta^2 ) * pi;
P.t35         = GW.Thetat.^(-1/4);
X.P(:,7)      = P.k0*P.t0 + P.k1*P.t1 + P.k15*P.t15 + P.k2*P.t2 + P.k25*P.t25 + P.k3.*P.t3 + P.k35*P.t35;

W.k35         = -( (188516689/433520640) + (97765/258048)*prm.eta - (141769/1290240)*prm.eta^2 ) * pi;
W.t35         = GW.Thetat.^(-5/4);
X.W(:,7)      = W.k0*W.t0 + W.k1*W.t1 + W.k15*W.t15 + W.k2*W.t2 + W.k25*W.t25 + W.k3.*W.t3 + W.k35*W.t35;

% -----------------------------------
% Compute phi(t) 
X.P           = (-1/prm.eta) * X.P;

% -----------------------------------
% Compute w(t) and f(t)
X.W           = (cfg.c3/(8*cfg.G*prm.Mtotal)) * X.W;
X.F           = X.W /(2*pi);

% % -----------------------------------
% % Plot for debugging
% 
% figure, clf, hold on
% % subplot(2,1,1), hold on
% plot(GW.t-GW.t(end) , X.P  , '-', 'MarkerSize',4, 'LineWidth',3);
% ylabel('\phi(t)'), xlabel('Time (s)')
% box on, grid on, set(gca,'FontSize',12)
% legend('0PN','1PN','1.5PN','2PN','2.5PN','3PN','3.5PN','Location','NorthWest')
% 
% figure, clf, hold on
% % subplot(2,1,2), hold on
% plot(GW.t-GW.t(end) , X.F  , '-', 'MarkerSize',4, 'LineWidth',3);
% ylabel('f(t)'), xlabel('Time (s)')
% box on, grid on, set(gca,'FontSize',12)
% legend('0PN','1PN','1.5PN','2PN','2.5PN','3PN','3.5PN','Location','SouthWest')
% % % 
% % % % X.A           = (4/prm.D) * ((cfg.G*prm.Mchirp/cfg.c2)^(5/3)) * ((pi*X.F /cfg.c).^(2/3));
% % % figure, clf, hold on
% % % % subplot(2,1,2), hold on
% % % plot(GW.t-GW.t(end) , X.A  , '-', 'MarkerSize',4, 'LineWidth',3);
% % % ylabel('A(t)'), xlabel('Time (s)')
% % % box on, grid on, set(gca,'FontSize',12)
% % % legend('0PN','1PN','1.5PN','2PN','2.5PN','3PN','3.5PN','Location','SouthWest')



%% 3) COMPUTE GW PHASE AND FREQUENCY

% -----------------------------------
if     PN==0
    GW.phit   = 2 * (X.P(:,1)-prm.phio);
    GW.ft     = 2 * X.F(:,1);
    
elseif PN==1
    GW.phit   = 2 * (X.P(:,2)-prm.phio);
    GW.ft     = 2 * X.F(:,2);
    
elseif PN==1.5
    GW.phit   = 2 * (X.P(:,3)-prm.phio);
    GW.ft     = 2 * X.F(:,3);
    
elseif PN==2
    GW.phit   = 2 * (X.P(:,4)-prm.phio);
    GW.ft     = 2 * X.F(:,4);
    
elseif PN==2.5
    GW.phit   = 2 * X.P(:,5);
    GW.ft     = 2 * X.F(:,5);
    
elseif PN==3
    GW.phit   = 2 * X.P(:,6);
    GW.ft     = 2 * X.F(:,6);
    
elseif PN==3.5
    GW.phit   = 2 * X.P(:,7);
    GW.ft     = 2 * X.F(:,7);
    
end


%% 4) COMPUTE $h_{+}(t)$ AND $h_{x}(t)$

% Tipo de ecuacion para calcular GW
tipo = 2; % PAPER POLARIZACIONES CLAUDIA USAR tipo = 2;

if     tipo==1
    % Thesis machos [pag. 36, equ. 2.102, 2.103] - Parte 1
    hct   = (2/cfg.c2) * (prm.mu/cfg.Msun) * (pi*cfg.G*prm.Mtotal*GW.ft).^(2/3) .* cos(GW.phit-prm.phio);
    hst   = (2/cfg.c2) * (prm.mu/cfg.Msun) * (pi*cfg.G*prm.Mtotal*GW.ft).^(2/3) .* sin(GW.phit-prm.phio);
    % Thesis machos [pag. 36, equ. 2.105, 2.106] - Parte 2
    GW.hp = - (1*cfg.G*cfg.Msun/(cfg.c2*prm.D)) * (2*prm.cosiota2) .* hct;
    GW.hx = - (2*cfg.G*cfg.Msun/(cfg.c2*prm.D)) * (1*prm.cosiota1) .* hst;
    
    % % Libro Magiore [Pag. 173, Equ. 431] - Option 2 - Revisar creo que esto solo aplica para el caso Newtoniano
    % GW.hmt0      = (1/prm.D) * ((cfg.G*prm.Mchirp/cfg.c2)^(5/4)) * ((5./(cfg.c*GW.tau)).^(1/4)) .* prm.cosiota2 .* cos(GW.phit);
    % GW.hxt0      = (1/prm.D) * ((cfg.G*prm.Mchirp/cfg.c2)^(5/4)) * ((5./(cfg.c*GW.tau)).^(1/4)) .* prm.cosiota1 .* sin(GW.phit);
    
elseif tipo==2
    % Libro Magiore [Pag. 173, Equ. 429] - Option 1
    GW.At      = (4/prm.D) * ((cfg.G*prm.Mchirp/cfg.c2)^(5/3)) * ((pi*GW.ft/cfg.c).^(2/3));
    
    % ----------------------
    % Polarizations from the relativistic theory: tensorial (plus and cross)
    GW.hp      = GW.At .* (1+(cos(prm.iota))^2)/2    .* cos(GW.phit);
    GW.hc      = GW.At .* cos(prm.iota)              .* sin(GW.phit);
    
    % ----------------------
    % Polarizations from the non-relativistic theory: non-tensorial (x,y) and scalar (b,l)
    GW.hx      = GW.At .* sin(2*prm.iota)/2          .* cos(GW.phit);
    GW.hy      = GW.At .* sin(prm.iota)              .* sin(GW.phit);
    GW.hb      = GW.At .* (sin(prm.iota)^2)          .* cos(GW.phit);
    GW.hl      = GW.At .* (sin(prm.iota)^2)/sqrt(2)  .* cos(GW.phit);
    
    % ----------------------
    % Polarizations from the Brans-Dicke theory tensorial (plus and cross) and scalar (b)
    omega     = 1e6; % 100 1e6
    chi       = 1/(2+omega);
    gg        = 1-chi/2;
    AmpBD     = (1-0.5*chi) * gg;
    %g         = 1-chi*(S-2*s1*s2);
    
    GW.hp_bd = GW.hp * AmpBD;
    GW.hc_bd = GW.hc * AmpBD;

    sp1        = 0;
    sp2        = 0;
    
    s1         = 0.5;
    s2         = 0.5;
    %s1         = 0.2839;
    %s2         = 0.1903;
    
    Lambda     = gg*(1-s1-s2) - chi*( (1-2*s1)*sp2 + (1-2*s2)*sp1 );
    Gamma      = 1 - 2*(prm.m1*s2-prm.m2*s1)/prm.Mtotal;
    Mag_BD     = gg .* chi;
    GW.hb_bd   = -GW.At .* Mag_BD .* ( (Gamma/2)*(sin(prm.iota)^2).*cos(GW.phit-prm.phio) - 1*((Gamma+2*Lambda)/2) + (s1-s2)*sqrt(prm.D/(prm.Mtotal*cfg.Msun))*sin(prm.iota)*cos(GW.phit-prm.phio) );
    
    % ----------------------
    % Polarizations from the Rosen theory
    % Recall that GW.phit in this implementation is 2*\phi(t)-2*\phi_o
     
    phit          = (GW.phit+2*prm.phio)/2;
    GB            = (s1/prm.m1)-(s2/prm.m2);
    ROSK          = (2/3) .* sqrt(prm.D/prm.Mtotal) .* GB;
    
    GW.hp_rosen   =  (GW.At/2) .* ( sin(phit).^2 - (cos(prm.iota)^2)*cos(phit).^2 );
    GW.hc_rosen   = -(GW.At/2) .* sin(2*phit) .* cos(prm.iota);
    
    GW.hx_rosen   = GW.At .* ( -cos(phit).*sin(phit).*sin(prm.iota)         - ROSK.*sin(phit) ); 
    GW.hy_rosen   = GW.At .* ( (sin(phit).^2).*sin(prm.iota).*cos(prm.iota) - ROSK.*cos(phit).*sin(prm.iota) );
    
    GW.hb_rosen   = (GW.At/2) .* ( (sin(prm.iota).^2).*(sin(phit).^2) + 1 - 2*ROSK.*sin(prm.iota).*cos(phit) );
    GW.hl_rosen   =  GW.At    .* ( (sin(prm.iota).^2).*(sin(phit).^2) - 1 -   ROSK.*sin(prm.iota).*cos(phit) );
    
    
    % ----------------------
    % Polarizations from the Lightman-Lee theory
    % Recall that GW.phit in this implementation is 2*\phi(t)-2*\phi_o
     
    phit           = (GW.phit+2*prm.phio)/2;
    GB             = (s1/prm.m1)-(s2/prm.m2);
    ROSK           = sqrt(prm.D/prm.Mtotal) .* GB;
    
    GW.hp_lightman =  (GW.At/2) .* ( sin(phit).^2 - (cos(prm.iota)^2)*cos(phit).^2 );
    GW.hc_lightman = -(GW.At/2) .* sin(2*phit) .* cos(prm.iota);
    
    GW.hx_lightman = GW.At .* ( -cos(phit).*sin(phit).*sin(prm.iota)         + (5/3)*ROSK.*sin(phit) ); 
    GW.hy_lightman = GW.At .* ( (sin(phit).^2).*sin(prm.iota).*cos(prm.iota) + (5/3)*ROSK.*cos(phit).*sin(prm.iota) );
    
    GW.hb_lightman = (GW.At/2) .* ( (sin(prm.iota).^2).*(cos(phit).^2) - (sin(prm.iota).^2).*(sin(phit).^2) + 1 - (25/6)*ROSK.*sin(prm.iota).*cos(phit) );
    GW.hl_lightman =  GW.At    .* ( (sin(prm.iota).^2).*(sin(phit).^2) - 3 - (5/3)*ROSK.*sin(prm.iota).*cos(phit) );
    
    
elseif tipo==3
    % % FindChirp paper [Equ. 3.1a and 3.1b]
    % FC.hmt       = - prm.cosiota2 * (cfg.G*prm.Mchirp/(cfg.c2*prm.D)) * ((prm.tc-FC.t)/(5*cfg.G*prm.Mchirp/cfg.c3)).^(-1/4) .* cos(FC.phit);
    % FC.hxt       = - prm.cosiota1 * (cfg.G*prm.Mchirp/(cfg.c2*prm.D)) * ((prm.tc-FC.t)/(5*cfg.G*prm.Mchirp/cfg.c3)).^(-1/4) .* sin(FC.phit);
    % % % From tesis Reducing false alarms in searches for GW from CBC [Equ.s 3.1a and 3.1b]
    % % FC.hmt       = - ((2*cfg.G)/(cfg.c4*cfg.D)) * cfg.mu * ((pi*cfg.G*cfg.M*FC.ft).^(2/3)) * (2*cfg.cosiota2) .* cos(FC.phit);
    % % FC.hxt       = - ((4*cfg.G)/(cfg.c4*cfg.D)) * cfg.mu * ((pi*cfg.G*cfg.M*FC.ft).^(2/3)) * (1*cfg.cosiota1) .* sin(FC.phit);
end

% Eliminar las ultimas muestras de la GW que resultan en valores complejos
Nsamples    = length(GW.t);
Sample2Eli  = [];
for i=Nsamples:-1:1    
    if (isreal(GW.hp(i)) && isreal(GW.hc(i)) && isreal(GW.hx(i)) && isreal(GW.hy(i)) && isreal(GW.hb(i)) && isreal(GW.hl(i)))
        break
        % PILAS: se hace asi pues en principio las unicas muestras que
        % pueden ser complejas son unicamente al final del inspiral phase
    else
        %fprintf('Eliminating sample %i of %i\n',i,Nsamples)
        Sample2Eli = [Sample2Eli i];
    end
end

GW.t(Sample2Eli)        = [];
GW.Thetat(Sample2Eli)   = [];
GW.ft(Sample2Eli)       = [];
GW.phit(Sample2Eli)     = [];
if PN==3.5
% GW.phit1(Sample2Eli)     = [];
% GW.phit2(Sample2Eli)     = [];
end
GW.At(Sample2Eli)       = [];

GW.hp(Sample2Eli)       = [];
GW.hc(Sample2Eli)       = [];

GW.hx(Sample2Eli)       = [];
GW.hy(Sample2Eli)       = [];

GW.hb(Sample2Eli)       = [];
GW.hl(Sample2Eli)       = [];

GW.hp_bd(Sample2Eli)    = [];
GW.hc_bd(Sample2Eli)    = [];
GW.hb_bd(Sample2Eli)    = [];

GW.hp_rosen(Sample2Eli) = [];
GW.hc_rosen(Sample2Eli) = [];
GW.hx_rosen(Sample2Eli) = [];
GW.hy_rosen(Sample2Eli) = [];
GW.hb_rosen(Sample2Eli) = [];
GW.hl_rosen(Sample2Eli) = [];

GW.hp_lightman(Sample2Eli) = [];
GW.hc_lightman(Sample2Eli) = [];
GW.hx_lightman(Sample2Eli) = [];
GW.hy_lightman(Sample2Eli) = [];
GW.hb_lightman(Sample2Eli) = [];
GW.hl_lightman(Sample2Eli) = [];

% a = GW.phit(end);
% GW.phit = GW.phit - GW.phit(end);
% b = GW.phit(end);
% disp([a b])


%% COALESCENCE TIME AT T=0
GW.t         = GW.t - GW.t(end);



%% PLOT

if doplot==1
    
    figure(1), clf, hold on
    
    plot(GW.t,GW.hp,'.-','MarkerSize',12)
    plot(GW.t,GW.hc,'o-','MarkerSize',4)
    plot(GW.t,GW.hx,'>-','MarkerSize',4)
    plot(GW.t,GW.hy,'<-','MarkerSize',4)
    plot(GW.t,GW.hb,'s-')
    plot(GW.t,GW.hl,'d-')
    legend('h_+','h_{\times}','h_{x}','h_{y}','h_{b}','h_{l}','Location','SouthWest')
    ylabel('h_{pol}'), xlabel('Time (s)')
    box on, grid on
    title(['\iota=' num2str(prm.iota*180/pi)])
    
end
