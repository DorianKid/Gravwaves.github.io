
prm.m1STR     = num2str(prm.m1);
prm.m2STR     = num2str(prm.m2);
prm.DMpcSTR   = num2str(prm.DMpc);

if prm.m1==1.32, prm.m1STR = '1p32'; end
if prm.m2==1.10, prm.m2STR = '1p10'; end
    
fn4all   = [prm.PNorderSTR '_masas' prm.m1STR 'y' prm.m2STR '_iota' num2str(prm.iotadegree) '_Dis' prm.DMpcSTR 'Mpc'];


% % GW150914
% m1             = 40;                % Mass 1 (sum masses)
% m2             = 30;                % Mass 2 (sum masses)
% DMpc           = 400;               % Distance (Mpc)

% NS-NS
% m1             = 1.32;              % Mass 1 (sum masses)
% m2             = 1.10;              % Mass 2 (sum masses)
% DMpc           =  37;               % Distance (Mpc)
%     thetadegree = 197;
%     phidegree   =  23;

% s1=0.2839
% s2=0.1903

% Llamar a 
% 5552262663