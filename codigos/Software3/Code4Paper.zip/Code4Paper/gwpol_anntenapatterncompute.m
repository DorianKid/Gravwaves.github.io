function [Fp, Fc, Fx, Fy, Fb, Fl] = gwpol_anntenapatterncompute(theta1,phi1,psi)
%clearvars; close all; clc, theta1=1.7; phi1=1.7; psi = 0; [Fp, Fc, Fx, Fy, Fb, Fl] = gwpol_anntenapatterncompute(theta1,phi1,psi,doplot)

% theta => Ranges from 0 to pi
% phi   => Ranges from 0 to 2pi
% psi   => Ranges from 0 to pi

% Schutz 2001, http://dx.doi.org/10.1088/0264-9381/28/12/125023, [Pag. 8, Equ. 2]
% Thesis machos [Pag. 21, Equ. 2.108 and 2.109]

Fp = 0.5*(1+cos(theta1).^2).*cos(2*phi1)*cos(2*psi) - cos(theta1).*sin(2*phi1)*sin(2*psi);
Fc = 0.5*(1+cos(theta1).^2).*cos(2*phi1)*sin(2*psi) - cos(theta1).*sin(2*phi1)*cos(2*psi);
Fx = -sin(theta1) .* (cos(theta1).*cos(2*phi1).*cos(psi)-sin(2*phi1).*sin(psi));
Fy = -sin(theta1) .* (cos(theta1).*cos(2*phi1).*sin(psi)+sin(2*phi1).*cos(psi));
Fb = -0.5 .* sin(theta1).^2 .* cos(2*phi1);
Fl = -Fb;
